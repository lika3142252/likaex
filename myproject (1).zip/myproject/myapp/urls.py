from django.urls import path
from . import views

urlpatterns = [
    path('', views.material_list, name='material_list'),
    path('edit/<str:pk>/', views.material_edit, name='material_edit'),
    path('add/', views.material_edit, name='material_add'),
    path('suppliers/', views.material_suppliers, name='material_suppliers'),
    path('batch/', views.materials_batch_view, name='materials_batch'),
]