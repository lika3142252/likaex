from django.db import models

class MaterialType(models.Model):
    material_type = models.CharField(max_length=100, primary_key=True)
    percentage_raw_materials = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'material_type'

    def __str__(self):
        return self.material_type


class Supplier(models.Model):
    postav_name = models.CharField(max_length=150, primary_key=True)
    postav_type = models.CharField(max_length=50)
    inn = models.BigIntegerField()
    rating = models.IntegerField()
    start_date_of_work_the_postav = models.DateField()

    class Meta:
        managed = False
        db_table = 'suppliers'

    def __str__(self):
        return self.postav_name


class Material(models.Model):
    material_name = models.CharField(max_length=100, primary_key=True)
    material_type = models.ForeignKey(
        MaterialType,
        on_delete=models.CASCADE,
        db_column='material_type'
    )
    price_unit_material = models.DecimalField(max_digits=10, decimal_places=2)
    count_in_stock = models.IntegerField()
    min_count = models.IntegerField()
    count_in_pack = models.IntegerField()
    unit_measurement = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'materials'

    def __str__(self):
        return self.material_name


class MaterialSupplier(models.Model):
    material_name = models.ForeignKey(
        Material,
        on_delete=models.CASCADE,
        db_column='material_name',
        primary_key=True
    )
    provider = models.ForeignKey(
        Supplier,
        on_delete=models.CASCADE,
        db_column='provider'
    )

    class Meta:
        managed = False
        db_table = 'material_suppliers'
        unique_together = (('material_name', 'provider'),)

    def __str__(self):
        return f"{self.material_name} — {self.provider}"