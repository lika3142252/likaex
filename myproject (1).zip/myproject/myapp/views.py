from django.shortcuts import render, get_object_or_404, redirect
from .models import Material, MaterialSupplier, Supplier, MaterialType
from .forms import MaterialForm
import math


def material_list(request):
    materials = Material.objects.all()
    return render(request, 'myapp/material_list.html', {'materials': materials})

def material_edit(request, pk=None):
    material = get_object_or_404(Material, pk=pk) if pk else None
    form = MaterialForm(request.POST or None, instance=material)
    if form.is_valid():
        form.save()
        return redirect('material_list')
    return render(request, 'myapp/material_edit.html', {'form': form})


def material_suppliers(request):
    suppliers = MaterialSupplier.objects.select_related('material_name', 'provider')
    return render(request, 'myapp/material_suppliers.html', {'suppliers': suppliers})

def materials_batch_view(request):
    materials = list(Material.objects.all())

    for m in materials:
        if m.count_in_stock >= m.min_count:
            m.batch_cost = 0.0
        else:
            shortage = m.min_count - m.count_in_stock
            packs = math.ceil(shortage / m.count_in_pack)
            m.batch_cost = round(packs * m.count_in_pack * m.price_unit_material, 2)

    return render(request, 'myapp/materials_batch_list.html', {'materials': materials})

def calculate_product_quantity(product_type_id: int, material_type_id: int,
    raw_material_qty: int, param1: float, param2: float) -> int:
    # Проверка валидности входных данных
    if raw_material_qty <= 0 or param1 <= 0 or param2 <= 0:
        return -1

    try:
        product = ProductType.objects.get(id=product_type_id)
        material = MaterialType.objects.get(material_type=material_type_id)
    except (ProductType.DoesNotExist, MaterialType.DoesNotExist):
        return -1

    # расчёт необходимого количества сырья на 1 единицу продукции
    raw_per_unit = param1 * param2 * product.coefficient

    # учёт потерь
    total_needed_per_unit = raw_per_unit * (1 + material.loss_percentage / 100)

    if total_needed_per_unit == 0:
        return -1

    # финальный расчёт количества продукции
    quantity = int(raw_material_qty // total_needed_per_unit)
    return quantity