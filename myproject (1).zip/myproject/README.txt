# Создать виртуальное окружение:
python -m venv venv
# Активировать:
venv\Scripts\activate
# Установить зависимости:
pip install -r requirements.txt
# Сделать миграции
python manage.py migrate
# Запустить сервер:
python manage.py runserver